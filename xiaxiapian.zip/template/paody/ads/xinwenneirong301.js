﻿MAC.AdsWrap(300,250,'xinwenneirong301广告位');
document.writeln("<script src='http:\/\/slb.gedawang.com\/s.php?id=13995'><\/script>");