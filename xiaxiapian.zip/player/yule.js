
MacPlayer.Html = '<iframe width="100%" height="'+MacPlayer.Height+'" src="http://vsxlme.bceapp.com/youkuyun.php?vid='+MacPlayer.PlayUrl+'" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>';
MacPlayer.Show();