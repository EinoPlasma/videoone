document.writeln('统计代码');
